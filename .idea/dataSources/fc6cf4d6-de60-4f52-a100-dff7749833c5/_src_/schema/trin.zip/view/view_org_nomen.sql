CREATE VIEW view_org_nomen AS
  SELECT
    `view_dogovory_parts`.`kod_org`   AS `kod_org`,
    `view_dogovory_parts`.`kod_elem`  AS `kod_elem`,
    sum(`view_dogovory_parts`.`numb`) AS `numb`,
    `view_dogovory_parts`.`name`      AS `name`
  FROM `trin`.`view_dogovory_parts`
  GROUP BY `view_dogovory_parts`.`kod_org`, `view_dogovory_parts`.`kod_elem`, `view_dogovory_parts`.`name`
  ORDER BY sum(`view_dogovory_parts`.`numb`) DESC;
