CREATE VIEW view_elem AS
  SELECT
    `trin`.`elem`.`kod_elem`  AS `kod_elem`,
    `trin`.`elem`.`obozn`     AS `obozn`,
    `trin`.`elem`.`name`      AS `name`,
    `trin`.`elem`.`shablon`   AS `shablon`,
    `trin`.`elem`.`nomen`     AS `nomen`,
    `trin`.`elem`.`time_mark` AS `time_mark`
  FROM `trin`.`elem`
  ORDER BY `trin`.`elem`.`obozn`, `trin`.`elem`.`nomen` DESC;
