CREATE VIEW view_sklad AS
  SELECT
    `trin`.`sklad`.`kod_part`              AS `kod_part`,
    `trin`.`sklad`.`numb`                  AS `numb`,
    `trin`.`elem`.`name`                   AS `name`,
    `trin`.`dogovory`.`kod_dogovora`       AS `kod_dogovora`,
    `trin`.`dogovory`.`nomer`              AS `nomer`,
    `trin`.`elem`.`kod_elem`               AS `kod_elem`,
    `trin`.`sklad`.`naklad`                AS `naklad`,
    `trin`.`org`.`kod_org`                 AS `kod_org`,
    `trin`.`org`.`nazv_krat`               AS `nazv_krat`,
    `trin`.`sklad`.`oper`                  AS `oper`,
    `trin`.`sklad`.`kod_oper`              AS `kod_oper`,
    `view_dogovor_summa`.`dogovor_summa`   AS `dogovor_summa`,
    `view_dogovor_summa_plat`.`summa_plat` AS `summa_plat`,
    `trin`.`sklad`.`data`                  AS `data`,
    `trin`.`sklad`.`kod_oborota`           AS `kod_oborota`,
    `trin`.`sklad`.`poluch`                AS `poluch`
  FROM ((((((`trin`.`sklad`
    JOIN `trin`.`parts` ON ((`trin`.`sklad`.`kod_part` = `trin`.`parts`.`kod_part`))) JOIN `trin`.`elem`
      ON ((`trin`.`parts`.`kod_elem` = `trin`.`elem`.`kod_elem`))) JOIN `trin`.`dogovory`
      ON ((`trin`.`parts`.`kod_dogovora` = `trin`.`dogovory`.`kod_dogovora`))) JOIN `trin`.`org`
      ON ((`trin`.`dogovory`.`kod_org` = `trin`.`org`.`kod_org`))) LEFT JOIN `trin`.`view_dogovor_summa`
      ON (((`trin`.`dogovory`.`kod_dogovora` = `view_dogovor_summa`.`kod_dogovora`) AND
           (`trin`.`dogovory`.`kod_dogovora` = `view_dogovor_summa`.`kod_dogovora`)))) LEFT JOIN
    `trin`.`view_dogovor_summa_plat` ON ((`trin`.`dogovory`.`kod_dogovora` = `view_dogovor_summa_plat`.`kod_dogovora`)))
  WHERE (`trin`.`sklad`.`kod_oper` = 2)
  ORDER BY `trin`.`sklad`.`data` DESC;
