CREATE VIEW view_dogovor_summa AS
  SELECT
    `trin`.`parts`.`kod_dogovora`                                                        AS `kod_dogovora`,
    sum(((`trin`.`parts`.`price` * `trin`.`parts`.`numb`) * (1 + `trin`.`parts`.`nds`))) AS `dogovor_summa`
  FROM `trin`.`parts`
  GROUP BY `trin`.`parts`.`kod_dogovora`
  ORDER BY `trin`.`parts`.`kod_dogovora` DESC;
