CREATE VIEW view_phones_kontakts AS
  SELECT
    `trin`.`kontakty`.`kod_kontakta` AS `kod_kontakta`,
    `trin`.`kontakty`.`dolg`         AS `dolg`,
    `trin`.`kontakty`.`famil`        AS `famil`,
    `trin`.`kontakty`.`name`         AS `name`,
    `trin`.`kontakty`.`otch`         AS `otch`,
    `trin`.`phones`.`phone`          AS `phone`,
    `trin`.`phones`.`prim`           AS `prim`
  FROM (`trin`.`kontakty`
    JOIN `trin`.`phones` ON ((`trin`.`kontakty`.`kod_kontakta` = `trin`.`phones`.`kod_kontakta`)));
