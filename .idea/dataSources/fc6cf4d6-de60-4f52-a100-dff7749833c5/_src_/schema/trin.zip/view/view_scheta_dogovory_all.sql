CREATE VIEW view_scheta_dogovory_all AS
  SELECT
    `view_dogovory_nvs`.`kod_org`            AS `kod_org`,
    `view_dogovory_nvs`.`kod_dogovora`       AS `kod_dogovora`,
    `view_dogovory_nvs`.`nomer`              AS `nomer`,
    `view_dogovory_nvs`.`kod_ispolnit`       AS `kod_ispolnit`,
    `view_dogovory_nvs`.`ispolnit_nazv_krat` AS `ispolnit_nazv_krat`,
    `view_dogovory_nvs`.`data_sost`          AS `data_sost`,
    `view_dogovory_nvs`.`nazv_krat`          AS `nazv_krat`
  FROM `trin`.`view_dogovory_nvs`
  UNION ALL SELECT
              `view_scheta_dogovora`.`kod_org`            AS `kod_org`,
              `view_scheta_dogovora`.`kod_dogovora`       AS `kod_dogovora`,
              `view_scheta_dogovora`.`nomer`              AS `nomer`,
              `view_scheta_dogovora`.`kod_ispolnit`       AS `kod_ispolnit`,
              `view_scheta_dogovora`.`ispolnit_nazv_krat` AS `ispolnit_nazv_krat`,
              `view_scheta_dogovora`.`data`               AS `DATA`,
              `view_scheta_dogovora`.`nazv_krat`          AS `nazv_krat`
            FROM `trin`.`view_scheta_dogovora`
  ORDER BY `data_sost` DESC;
