CREATE VIEW view_docum_elem AS
  SELECT
    `trin`.`docum_elem`.`kod_elem` AS `kod_elem`,
    `trin`.`docum`.`name`          AS `name`,
    `trin`.`docum`.`path`          AS `path`,
    `trin`.`docum`.`kod_docum`     AS `kod_docum`
  FROM (`trin`.`docum`
    JOIN `trin`.`docum_elem` ON ((`trin`.`docum_elem`.`kod_docum` = `trin`.`docum`.`kod_docum`)));
