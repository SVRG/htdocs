CREATE VIEW view_dogovory_elem AS
  SELECT
    `view_dogovory_nvs`.`kod_dogovora`       AS `kod_dogovora`,
    `view_dogovory_nvs`.`nomer`              AS `nomer`,
    `view_dogovory_nvs`.`data_sost`          AS `data_sost`,
    `view_dogovory_nvs`.`kod_org`            AS `kod_org`,
    `view_dogovory_nvs`.`nazv_krat`          AS `nazv_krat`,
    `view_dogovory_nvs`.`zakryt`             AS `zakryt`,
    `view_dogovory_nvs`.`kod_ispolnit`       AS `kod_ispolnit`,
    `view_dogovory_nvs`.`ispolnit_nazv_krat` AS `ispolnit_nazv_krat`,
    `trin`.`parts`.`kod_elem`                AS `kod_elem`
  FROM (`trin`.`parts`
    JOIN `trin`.`view_dogovory_nvs` ON ((`view_dogovory_nvs`.`kod_dogovora` = `trin`.`parts`.`kod_dogovora`)));
