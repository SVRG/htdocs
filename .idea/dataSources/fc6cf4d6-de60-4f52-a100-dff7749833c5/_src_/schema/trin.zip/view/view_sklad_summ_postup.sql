CREATE VIEW view_sklad_summ_postup AS
  SELECT
    `view_sklad_postuplenie`.`kod_part`  AS `kod_part`,
    sum(`view_sklad_postuplenie`.`numb`) AS `summ_postup`
  FROM `trin`.`view_sklad_postuplenie`
  GROUP BY `view_sklad_postuplenie`.`kod_part`;
