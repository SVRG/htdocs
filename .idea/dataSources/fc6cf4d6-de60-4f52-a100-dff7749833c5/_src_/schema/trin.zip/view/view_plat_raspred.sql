CREATE VIEW view_plat_raspred AS
  SELECT
    `trin`.`plat`.`kod_plat`            AS `kod_plat`,
    sum(`trin`.`raschety_plat`.`summa`) AS `summa_raspred`
  FROM (`trin`.`raschety_plat`
    JOIN `trin`.`plat` ON ((`trin`.`plat`.`kod_plat` = `trin`.`raschety_plat`.`kod_plat`)))
  GROUP BY `trin`.`plat`.`kod_plat`;
