CREATE VIEW view_scheta_dogovora AS
  SELECT
    `trin`.`scheta`.`nomer`                  AS `nomer`,
    `trin`.`scheta`.`data`                   AS `data`,
    `view_dogovory_nvs`.`kod_ispolnit`       AS `kod_ispolnit`,
    `view_dogovory_nvs`.`ispolnit_nazv_krat` AS `ispolnit_nazv_krat`,
    `view_dogovory_nvs`.`kod_org`            AS `kod_org`,
    `view_dogovory_nvs`.`data_sost`          AS `data_sost`,
    `view_dogovory_nvs`.`kod_dogovora`       AS `kod_dogovora`,
    `view_dogovory_nvs`.`nazv_krat`          AS `nazv_krat`
  FROM (`trin`.`view_dogovory_nvs`
    JOIN `trin`.`scheta` ON ((`view_dogovory_nvs`.`kod_dogovora` = `trin`.`scheta`.`kod_dogovora`)));
