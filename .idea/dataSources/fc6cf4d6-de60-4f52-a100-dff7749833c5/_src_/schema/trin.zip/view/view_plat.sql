CREATE VIEW view_plat AS
  SELECT
    `trin`.`plat`.`nomer`               AS `nomer`,
    `trin`.`plat`.`summa`               AS `summa`,
    `trin`.`plat`.`data`                AS `data`,
    `trin`.`plat`.`prim`                AS `prim`,
    `view_dogovory_nvs`.`kod_dogovora`  AS `kod_dogovora`,
    `view_dogovory_nvs`.`nomer`         AS `nomer_dogovora`,
    `view_dogovory_nvs`.`kod_org`       AS `kod_org`,
    `view_dogovory_nvs`.`nazv_krat`     AS `nazv_krat`,
    `view_plat_raspred`.`summa_raspred` AS `summa_raspred`,
    `trin`.`plat`.`kod_plat`            AS `kod_plat`
  FROM ((`trin`.`plat`
    JOIN `trin`.`view_dogovory_nvs` ON ((`trin`.`plat`.`kod_dogovora` = `view_dogovory_nvs`.`kod_dogovora`))) LEFT JOIN
    `trin`.`view_plat_raspred` ON ((`trin`.`plat`.`kod_plat` = `view_plat_raspred`.`kod_plat`)));
