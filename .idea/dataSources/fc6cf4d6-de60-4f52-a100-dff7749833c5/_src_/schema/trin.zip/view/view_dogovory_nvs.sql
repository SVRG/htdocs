CREATE VIEW view_dogovory_nvs AS
  SELECT
    `trin`.`dogovory`.`kod_dogovora` AS `kod_dogovora`,
    `trin`.`dogovory`.`nomer`        AS `nomer`,
    `trin`.`dogovory`.`data_sost`    AS `data_sost`,
    `trin`.`dogovory`.`kod_org`      AS `kod_org`,
    `trin`.`org`.`nazv_krat`         AS `nazv_krat`,
    `trin`.`dogovory`.`zakryt`       AS `zakryt`,
    `trin`.`dogovory`.`kod_ispolnit` AS `kod_ispolnit`,
    `org_ispolnit`.`nazv_krat`       AS `ispolnit_nazv_krat`
  FROM ((`trin`.`dogovory`
    JOIN `trin`.`org` ON ((`trin`.`dogovory`.`kod_org` = `trin`.`org`.`kod_org`))) JOIN `trin`.`org` `org_ispolnit`
      ON ((`trin`.`dogovory`.`kod_ispolnit` = `org_ispolnit`.`kod_org`)))
  ORDER BY `trin`.`dogovory`.`data_sost` DESC;
