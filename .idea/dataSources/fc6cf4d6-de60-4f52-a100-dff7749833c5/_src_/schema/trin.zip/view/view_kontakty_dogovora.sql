CREATE VIEW view_kontakty_dogovora AS
  SELECT
    `trin`.`kontakty`.`kod_kontakta`          AS `kod_kontakta`,
    `trin`.`kontakty`.`kod_org`               AS `kod_org`,
    `trin`.`kontakty`.`dolg`                  AS `dolg`,
    `trin`.`kontakty`.`famil`                 AS `famil`,
    `trin`.`kontakty`.`name`                  AS `name`,
    `trin`.`kontakty`.`otch`                  AS `otch`,
    `trin`.`kontakty_dogovora`.`kod_dogovora` AS `kod_dogovora`,
    `trin`.`org`.`nazv_krat`                  AS `nazv_krat`
  FROM ((`trin`.`kontakty`
    JOIN `trin`.`kontakty_dogovora`
      ON ((`trin`.`kontakty`.`kod_kontakta` = `trin`.`kontakty_dogovora`.`kod_kontakta`))) JOIN `trin`.`org`
      ON ((`trin`.`kontakty`.`kod_org` = `trin`.`org`.`kod_org`)));
