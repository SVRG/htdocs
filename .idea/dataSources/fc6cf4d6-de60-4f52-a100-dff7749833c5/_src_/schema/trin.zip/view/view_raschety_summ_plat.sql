CREATE VIEW view_raschety_summ_plat AS
  SELECT
    `trin`.`raschet`.`kod_rascheta`           AS `kod_rascheta`,
    ifnull(`trin`.`raschety_plat`.`summa`, 0) AS `summa_plat`,
    `trin`.`raschet`.`kod_part`               AS `kod_part`,
    `trin`.`raschet`.`summa`                  AS `summa`
  FROM (`trin`.`raschet`
    LEFT JOIN `trin`.`raschety_plat` ON ((`trin`.`raschety_plat`.`kod_rascheta` = `trin`.`raschet`.`kod_rascheta`)))
  GROUP BY `trin`.`raschet`.`kod_rascheta`;
