CREATE VIEW view_dogovor_summa_plat AS
  SELECT
    sum(`trin`.`plat`.`summa`)   AS `summa_plat`,
    `trin`.`plat`.`kod_dogovora` AS `kod_dogovora`
  FROM `trin`.`plat`
  GROUP BY `trin`.`plat`.`kod_dogovora`
  ORDER BY `trin`.`plat`.`kod_dogovora` DESC;
