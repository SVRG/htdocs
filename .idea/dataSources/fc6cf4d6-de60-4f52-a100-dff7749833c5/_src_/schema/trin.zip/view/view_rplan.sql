CREATE VIEW view_rplan AS
  SELECT
    `view_dogovory_parts`.`kod_dogovora`                    AS `kod_dogovora`,
    `view_dogovory_parts`.`nomer`                           AS `nomer`,
    `view_dogovory_parts`.`kod_org`                         AS `kod_org`,
    `view_dogovory_parts`.`nazv_krat`                       AS `nazv_krat`,
    `view_dogovory_parts`.`modif`                           AS `modif`,
    `view_dogovory_parts`.`numb`                            AS `numb`,
    `view_dogovory_parts`.`data_postav`                     AS `data_postav`,
    round(`view_dogovory_parts`.`nds`, 2)                   AS `nds`,
    round(ifnull(`view_dogovory_parts`.`part_summa`, 0), 2) AS `part_summa`,
    `view_dogovory_parts`.`val`                             AS `val`,
    `view_dogovory_parts`.`price`                           AS `price`,
    `view_dogovory_parts`.`kod_elem`                        AS `kod_elem`,
    `view_dogovory_parts`.`obozn`                           AS `obozn`,
    `view_dogovory_parts`.`kod_part`                        AS `kod_part`,
    `view_dogovory_parts`.`zakryt`                          AS `zakryt`,
    `view_dogovory_parts`.`kod_ispolnit`                    AS `kod_ispolnit`,
    `view_dogovory_parts`.`name`                            AS `name`,
    `view_dogovory_parts`.`ispolnit_nazv_krat`              AS `ispolnit_nazv_krat`
  FROM `trin`.`view_dogovory_parts`;
