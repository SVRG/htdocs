CREATE VIEW view_sklad_otgruzka AS
  SELECT
    `trin`.`sklad`.`kod_part` AS `kod_part`,
    `trin`.`sklad`.`numb`     AS `numb`,
    `trin`.`sklad`.`kod_oper` AS `kod_oper`
  FROM `trin`.`sklad`
  WHERE (`trin`.`sklad`.`kod_oper` = 2);
