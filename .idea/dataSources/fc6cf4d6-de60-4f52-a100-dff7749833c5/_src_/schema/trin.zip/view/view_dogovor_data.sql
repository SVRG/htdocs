CREATE VIEW view_dogovor_data AS
  SELECT
    `view_dogovory_nvs`.`kod_dogovora`                            AS `kod_dogovora`,
    `view_dogovory_nvs`.`nomer`                                   AS `nomer`,
    `view_dogovory_nvs`.`data_sost`                               AS `data_sost`,
    `view_dogovory_nvs`.`kod_org`                                 AS `kod_org`,
    `view_dogovory_nvs`.`zakryt`                                  AS `zakryt`,
    `view_dogovory_nvs`.`nazv_krat`                               AS `nazv_krat`,
    `view_dogovory_nvs`.`kod_ispolnit`                            AS `kod_ispolnit`,
    `view_dogovory_nvs`.`ispolnit_nazv_krat`                      AS `ispolnit_nazv_krat`,
    round(ifnull(`view_dogovor_summa`.`dogovor_summa`, 0), 2)     AS `dogovor_summa`,
    round(ifnull(`view_dogovor_summa_plat`.`summa_plat`, 0), 2)   AS `summa_plat`,
    (round(ifnull(`view_dogovor_summa`.`dogovor_summa`, 0), 2) -
     round(ifnull(`view_dogovor_summa_plat`.`summa_plat`, 0), 2)) AS `dogovor_ostat`
  FROM ((`trin`.`view_dogovory_nvs`
    LEFT JOIN `trin`.`view_dogovor_summa`
      ON ((`view_dogovor_summa`.`kod_dogovora` = `view_dogovory_nvs`.`kod_dogovora`))) LEFT JOIN
    `trin`.`view_dogovor_summa_plat`
      ON ((`view_dogovor_summa_plat`.`kod_dogovora` = `view_dogovory_nvs`.`kod_dogovora`)));
