CREATE VIEW view_sklad_summ_otgruz AS
  SELECT
    `view_sklad_otgruzka`.`kod_part`  AS `kod_part`,
    sum(`view_sklad_otgruzka`.`numb`) AS `summ_otgruz`
  FROM `trin`.`view_sklad_otgruzka`
  GROUP BY `view_sklad_otgruzka`.`kod_part`;
