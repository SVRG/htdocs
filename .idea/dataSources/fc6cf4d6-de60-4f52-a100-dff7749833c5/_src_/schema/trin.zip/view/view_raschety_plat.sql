CREATE VIEW view_raschety_plat AS
  SELECT
    `trin`.`raschet`.`kod_rascheta`   AS `kod_rascheta`,
    `trin`.`raschet`.`kod_part`       AS `kod_part`,
    `trin`.`raschet`.`summa`          AS `raschet_summa`,
    `trin`.`raschet`.`data`           AS `data_rascheta`,
    `trin`.`raschet`.`type_rascheta`  AS `type_rascheta`,
    `trin`.`raschety_plat`.`kod_plat` AS `kod_plat`,
    `trin`.`raschety_plat`.`summa`    AS `summa_raspred`,
    `trin`.`plat`.`nomer`             AS `nomer`,
    `trin`.`plat`.`data`              AS `data_plat`,
    `trin`.`plat`.`prim`              AS `prim`,
    `trin`.`plat`.`kod_dogovora`      AS `kod_dogovora`
  FROM ((`trin`.`raschet`
    JOIN `trin`.`raschety_plat` ON ((`trin`.`raschet`.`kod_rascheta` = `trin`.`raschety_plat`.`kod_rascheta`))) JOIN
    `trin`.`plat` ON ((`trin`.`raschety_plat`.`kod_plat` = `trin`.`plat`.`kod_plat`)));
