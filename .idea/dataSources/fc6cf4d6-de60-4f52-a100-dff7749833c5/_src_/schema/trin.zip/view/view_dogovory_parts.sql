CREATE VIEW view_dogovory_parts AS
  SELECT
    `trin`.`dogovory`.`kod_dogovora`                                                                     AS `kod_dogovora`,
    `trin`.`dogovory`.`nomer`                                                                            AS `nomer`,
    `trin`.`org`.`kod_org`                                                                               AS `kod_org`,
    `trin`.`org`.`nazv_krat`                                                                             AS `nazv_krat`,
    `trin`.`parts`.`modif`                                                                               AS `modif`,
    `trin`.`parts`.`numb`                                                                                AS `numb`,
    `trin`.`parts`.`data_postav`                                                                         AS `data_postav`,
    round(`trin`.`parts`.`nds`, 2)                                                                       AS `nds`,
    round(ifnull(((`trin`.`parts`.`numb` * `trin`.`parts`.`price`) * (1 + `trin`.`parts`.`nds`)), 0),
          2)                                                                                             AS `part_summa`,
    `trin`.`parts`.`val`                                                                                 AS `val`,
    `trin`.`parts`.`price`                                                                               AS `price`,
    `trin`.`elem`.`kod_elem`                                                                             AS `kod_elem`,
    `trin`.`elem`.`obozn`                                                                                AS `obozn`,
    `trin`.`parts`.`kod_part`                                                                            AS `kod_part`,
    `trin`.`dogovory`.`zakryt`                                                                           AS `zakryt`,
    `trin`.`dogovory`.`kod_ispolnit`                                                                     AS `kod_ispolnit`,
    `trin`.`elem`.`name`                                                                                 AS `name`,
    `ispolnit`.`nazv_krat`                                                                               AS `ispolnit_nazv_krat`
  FROM ((((`trin`.`dogovory`
    JOIN `trin`.`parts` ON ((`trin`.`dogovory`.`kod_dogovora` = `trin`.`parts`.`kod_dogovora`))) JOIN `trin`.`org`
      ON ((`trin`.`org`.`kod_org` = `trin`.`dogovory`.`kod_org`))) JOIN `trin`.`elem`
      ON ((`trin`.`elem`.`kod_elem` = `trin`.`parts`.`kod_elem`))) JOIN `trin`.`org` `ispolnit`
      ON ((`ispolnit`.`kod_org` = `trin`.`dogovory`.`kod_ispolnit`)))
  ORDER BY `trin`.`dogovory`.`kod_dogovora` DESC;
