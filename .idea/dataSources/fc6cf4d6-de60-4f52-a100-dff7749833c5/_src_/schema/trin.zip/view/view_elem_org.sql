CREATE VIEW view_elem_org AS
  SELECT
    `view_dogovory_parts`.`kod_org`   AS `kod_org`,
    `view_dogovory_parts`.`kod_elem`  AS `kod_elem`,
    `view_dogovory_parts`.`nazv_krat` AS `nazv_krat`,
    sum(`view_dogovory_parts`.`numb`) AS `numb`
  FROM (`trin`.`view_dogovor_summa_plat`
    JOIN `trin`.`view_dogovory_parts`
      ON ((`view_dogovor_summa_plat`.`kod_dogovora` = `view_dogovory_parts`.`kod_dogovora`)))
  GROUP BY `view_dogovory_parts`.`kod_org`, `view_dogovory_parts`.`kod_elem`, `view_dogovory_parts`.`nazv_krat`
  ORDER BY sum(`view_dogovory_parts`.`numb`) DESC;
